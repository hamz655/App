package com.firstapp.appliancetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    OkHttpClient client = new OkHttpClient();
    TextView txtString;
    public String url;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtString = findViewById(R.id.url);
        url = (String) txtString.getText().toString();

        Button post_request_button=findViewById(R.id.post_data);
        OkHttpHandler okHttpHandler= new OkHttpHandler();
//        get_response_button.setOnClickListener(new View.OnClick Listener() {
//            @Override
//                    public void onClick(View v) {
//                        sendGetRequest();
//            }
//        });
        post_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                okHttpHandler.execute(url);


            }
        });
    }

    public class OkHttpHandler extends AsyncTask {

        OkHttpClient client = new OkHttpClient();


        protected String doInBackground(String... params) {

            Request.Builder builder = new Request.Builder();
            builder.url(params[0]);
            Request request = builder.build();

            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            txtString.setText(s);
        }


        @Override
        protected Object doInBackground(Object[] objects) {
//            Request.Builder builder = new Request.Builder();
//            builder.url((String) objects[0]);
//            Request request = builder.build();
//
//            try {
//                Response response = client.newCall(request).execute();
//                return response.body().string();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
            return null;
        }

    }
    }